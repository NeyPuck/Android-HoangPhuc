package com.example.csc13009_android_ckdp.Alarm.AlarmList

import com.example.csc13009_android_ckdp.Alarm.Model.Alarm

interface OnToggleListener {
    fun onToggle(alarm: Alarm)
}