package com.example.csc13009_android_ckdp.FirstAid

class FirstAid(var name: Int, var imageSource: Int, var code: Int) {
}