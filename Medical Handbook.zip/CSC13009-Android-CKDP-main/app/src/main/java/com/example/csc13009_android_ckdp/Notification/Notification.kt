package com.example.csc13009_android_ckdp.Notification

class Notification(var notiID : String, var srcID : String, var type: String, var content: String, var time: String) {
}