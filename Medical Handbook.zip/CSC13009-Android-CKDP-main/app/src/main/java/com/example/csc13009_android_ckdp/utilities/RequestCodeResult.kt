package com.example.csc13009_android_ckdp.utilities

import android.content.SharedPreferences

public class RequestCodeResult {

    companion object {
        const val CHANGE_PASSWORD: Int = 5200
        const val CHANGE_INFORMATION: Int = 5201
        const val CHANGE_EMAIL: Int = 5202
        const val MY_PERMISSIONS_REQUEST_CALL_PHONE: Int = 5230
        const val LOGIN_GOOGLE_REQUEST: Int = 9439
    }
}